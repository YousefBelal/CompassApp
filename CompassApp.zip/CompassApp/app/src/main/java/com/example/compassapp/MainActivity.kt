package com.example.compassapp

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.Arrangement.Absolute.Center
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Alignment.Companion.CenterVertically
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.compassapp.ui.theme.CompassAppTheme
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    @ExperimentalMaterialApi
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CompassAppTheme {
                // A surface container using the 'background' color from the theme
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(color = Color.Black)
                ) {
                    mainB()
                }
            }
            }
        }
    }


@ExperimentalMaterialApi
@Composable
fun mainB(){
    val scope = rememberCoroutineScope()

    val bottomSheetScaffoldState = rememberBottomSheetScaffoldState(
        bottomSheetState = rememberBottomSheetState(initialValue = BottomSheetValue.Collapsed)
    )
    BottomSheetScaffold(
        sheetShape= RoundedCornerShape(topEnd =40.dp , topStart =40.dp ),
        sheetBackgroundColor= Color(0xFF0D1920),
        scaffoldState = bottomSheetScaffoldState,
        sheetPeekHeight = 56.dp,
        sheetContent = {
            LazyColumn() {
                item {
                    sheet_button()
                }
                item(){
                    SimpleRadioButtonComponent()
                }
                item {
                    addLocation_btn()
                }

            }
        }
    ) {
    }
}

@Composable
fun sheet_button(){
    Row(modifier=Modifier.padding(horizontal = 180.dp)) {
        Icon(painter = painterResource(id = R.drawable.ic_drag_handle), contentDescription = "",
            modifier= Modifier
                .size(40.dp),
            tint = Color.White
        )
    }
}

@Composable
fun SimpleRadioButtonComponent() {
    val radioOptions = listOf("AL Qibla ")
    val (selectedOption, onOptionSelected) = remember { mutableStateOf("") }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .fillMaxHeight(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Column {
            radioOptions.forEach { text ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .height(100.dp)
                        .selectable(
                            selected = (text == selectedOption),
                            onClick = { onOptionSelected(text) }
                        )
                        .padding(horizontal = 32.dp)
                        .border(3.dp, Color(36, 83, 175), shape = RoundedCornerShape(10.dp)),
                    horizontalArrangement=Center,
                    verticalAlignment=CenterVertically
                ) {
                    val context = LocalContext.current
                    RadioButton(
                        selected = (text == selectedOption),
                        modifier = Modifier.padding(all = Dp(value = 6F)),
                        onClick = {
                            onOptionSelected(text)
                            Toast.makeText(context, text, Toast.LENGTH_LONG).show()
                        },
                        colors = RadioButtonDefaults.colors(Color.White)
                    )
                    Text(
                        text = text,
                        fontSize=16.sp,
                        color= Color.White,
                        modifier = Modifier.padding(start = 16.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun addLocation_btn(){
    Row(
        Modifier
            .fillMaxWidth()
            .height(100.dp)
            .padding(horizontal = 32.dp),
        horizontalArrangement=Center,
        verticalAlignment=CenterVertically
    ){
        Box(
            Modifier
                .width(40.dp)
                .height(40.dp)
                .background(color=Color(36, 83, 175),shape= RoundedCornerShape(10.dp))
                .clickable {  }
        ){
            Icon(painter = painterResource(id = R.drawable.ic_add), contentDescription = "",
                modifier= Modifier
                    .size(40.dp),
                tint = Color.White
            )

        }

    }
}
@Composable
fun Place_Screen(){

}



@ExperimentalMaterialApi
@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    CompassAppTheme {
        mainB()
    }
}